import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminpanelService {

  constructor(private http: HttpClient) { }


  getCoursesAll(): Observable<any> {
    return this.http.get(environment.URL + "/courses");
  }  

  getUsersAll(): Observable<any> {
    return this.http.get(environment.URL + "/usersall");
  }  
   
  saveCourse(course: any): Observable<any>{
    return this.http.post(environment.URL + "/courses", JSON.stringify(course));    
  }

  uploadFile(myFiles: any): Observable<any> {
    const formData = new FormData();
    for (var i = 0; i < myFiles.length; i++) {
      formData.append("file[]", myFiles[i]);
      //console.log("Archivo: " + myFiles[i].name);
    }
    var uploadfile = environment.URL.replace('index.php','upload.php');
    return this.http.post(uploadfile, formData);
  }  

}
