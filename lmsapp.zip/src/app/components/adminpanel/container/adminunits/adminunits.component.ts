import { Component } from '@angular/core';
import {AdminpanelComponent} from '../../adminpanel.component';

@Component({
  selector: 'app-adminunits',
  templateUrl: './adminunits.component.html',
  styleUrls: ['./adminunits.component.css']
})
export class AdminunitsComponent {

  constructor(private adminpanelComponent:AdminpanelComponent){
    // this.adminpanelComponent.cargarTodosLosCursos();
  }

}
