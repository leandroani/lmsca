import { Component } from '@angular/core';
import {AdminpanelComponent} from '../../adminpanel.component';

@Component({
  selector: 'app-adminquestionnaire',
  templateUrl: './adminquestionnaire.component.html',
  styleUrls: ['./adminquestionnaire.component.css']
})
export class AdminquestionnaireComponent {

  constructor(private adminpanelComponent:AdminpanelComponent){
    // this.adminpanelComponent.cargarTodosLosCursos();
  }
  
}
