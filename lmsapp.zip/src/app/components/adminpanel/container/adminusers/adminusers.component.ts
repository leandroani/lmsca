import { Component } from '@angular/core';
import {AdminpanelComponent} from '../../adminpanel.component';

@Component({
  selector: 'app-adminusers',
  templateUrl: './adminusers.component.html',
  styleUrls: ['./adminusers.component.css']
})
export class AdminusersComponent {

}
