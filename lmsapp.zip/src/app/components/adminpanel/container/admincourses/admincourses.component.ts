import { Component } from '@angular/core';
import { AdminpanelComponent } from '../../adminpanel.component';
import { environment } from 'environments';
import { AdminpanelService } from '../../adminpanel.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-admincourses',
  templateUrl: './admincourses.component.html',
  styleUrls: ['./admincourses.component.css']
})
export class AdmincoursesComponent {

  public myform!: FormGroup;
  public msgLoadFiles: string = "";
  public urlapp: string = environment.URL + "/upload/";
  public fileList: File[] = [];


  constructor(private adminpanelComponent: AdminpanelComponent, private adminpanelService: AdminpanelService, private formBuilder: FormBuilder) {

    this.adminpanelComponent.cargarTodosLosCursos();

    

    this.myform = this.formBuilder.group({
      title: ['', [Validators.required, Validators.minLength(2)]],
      description: ['', [Validators.required, Validators.minLength(2)]],
      imagen: ['', [Validators.required]]
    });

  }


  onFileSelected(event: any) {
    this.fileList = [];
    for (var i = 0; i <= event.target.files.length - 1; i++) {
      var selectedFile = event.target.files[i];
      console.log("Nombre del archivo: " + selectedFile.name);
      this.fileList.push(selectedFile);
    }
    this.adminpanelService.uploadFile(this.fileList).subscribe(response => {
      if (response.estado == "ok") {
        this.msgLoadFiles = "Archivo seleccionado con exito!";
        this.myform.controls['imagen'].setValue(response.urls);

        var imagen = '../../../' + response.urls;
        var elemento = document.createElement("img");
        elemento.setAttribute("src",imagen);
        var actual = document.getElementById('imagen_actual');
        actual!.appendChild(elemento);        

      } else {
        this.msgLoadFiles = "Algo salio mal!";
      }
    });
  }

  saveCourse() {

    var title = this.myform.get("title")?.value;
    var description = this.myform.get("description")?.value;
    var imagen = this.myform.get("imagen")?.value;
    imagen = './upload/' + imagen ;

    var curso = { "title": title, "description": description, "imagen": imagen };

    this.adminpanelComponent.guardarCurso(curso).subscribe(
      data => {        
        var elemento = document.getElementById('mensaje');    
        if(data['data'].estado == "OK"){
          elemento!.innerHTML = '<div class="alert alert-success" role="alert"><p>Se creo un nuevo curso!!!</p></div>';
        }else{
          elemento!.innerHTML = '<div class="alert alert-danger" role="alert"><p>No fue posible crear un curso!</p></div>';
        }
        setTimeout(() =>{
          elemento!.innerHTML = "";
          // this.cargarCuestionario(this.unidad!,this.usuario);
        }, 3000);           

      },
      error => {
        console.log("saveCourse: no se pudieron recuperar datos. " + error);
      }
    );
    
  }


}
