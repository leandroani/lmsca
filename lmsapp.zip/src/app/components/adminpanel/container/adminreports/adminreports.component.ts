import { Component } from '@angular/core';
import {AdminpanelComponent} from '../../adminpanel.component';

@Component({
  selector: 'app-adminreports',
  templateUrl: './adminreports.component.html',
  styleUrls: ['./adminreports.component.css']
})
export class AdminreportsComponent {

  constructor(private adminpanelComponent:AdminpanelComponent){
    // this.adminpanelComponent.cargarTodosLosCursos();
  }
  
}
