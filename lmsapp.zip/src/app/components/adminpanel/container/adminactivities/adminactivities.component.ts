import { Component } from '@angular/core';
import {AdminpanelComponent} from '../../adminpanel.component';

@Component({
  selector: 'app-adminactivities',
  templateUrl: './adminactivities.component.html',
  styleUrls: ['./adminactivities.component.css']
})
export class AdminactivitiesComponent {

  constructor(private adminpanelComponent:AdminpanelComponent){
    // this.adminpanelComponent.cargarTodosLosCursos();
  }
  
}
