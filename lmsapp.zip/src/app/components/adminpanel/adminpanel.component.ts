import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminpanelService } from './adminpanel.service';

@Component({
  selector: 'app-adminpanel',
  templateUrl: './adminpanel.component.html',
  styleUrls: ['./adminpanel.component.css']
})
export class AdminpanelComponent {

  cursos: any = [];
  usuarios: any = [];

  constructor(private _router: ActivatedRoute, private router: Router, private adminpanelService: AdminpanelService) { }

  ngOnInit() {
    
    //this.cargarTodosLosCursos();
    // this.cargarTodosLosUsuarios();
  }


  cargarTodosLosCursos(): any {
    return this.adminpanelService.getCoursesAll().subscribe(
      data => {
        this.cursos = data;
      },
      error => {
        console.log("cargarTodosLosCursos: no se pudieron recuperar datos. " + error);
      }
    );
  }

  cargarTodosLosUsuarios(): any {
    return this.adminpanelService.getUsersAll().subscribe(
      data => {
        this.usuarios = data;
      },
      error => {
        console.log("cargarTodosLosUsuarios: no se pudieron recuperar datos. " + error);
      }
    );
  }  

  guardarCurso(curso:any){
    return this.adminpanelService.saveCourse(curso);    
  }

}
