import { Component } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import { ActivitiesService } from './activities.service';

// Esta declaracion es importante para que dal la funcionalidad de JQuery.
declare var $: any;

@Component({
  selector: 'app-activities',
  templateUrl: './activities.component.html',
  styleUrls: ['./activities.component.css']
})
export class ActivitiesComponent {
  
  private history: string[] = [];

  idcurso: string | undefined;
  idunit: string | undefined;
  unidad: number | undefined;
  curso: number | undefined;
  
  actividades: any = [];
  preguntas: any = [];
  preguntas_opciones: any = [];
  usuario = 1; // el Id lo deveria rescatar desde el localStorage.getItem("xxxx")

  constructor(private _router: ActivatedRoute, private router: Router, private activitiesService:ActivitiesService) {
    this.idcurso = this._router.snapshot.paramMap.get('idcurso')?.toString(); 
    this.idunit = this._router.snapshot.paramMap.get('idunit')?.toString();  
    
    console.log("Debug: Component Activities= Curso " + this.idcurso + " con Contenido de la unidad: " + this.idunit);

    this.unidad = parseInt(this.idunit!);
    this.curso = parseInt(this.idcurso!);

    this.cargarActividades(this.unidad);
    this.cargarCuestionario(this.unidad,this.usuario);
  }

  cargarActividades(idunidad:number): any {
    return this.activitiesService.getActivitiesByUnit(idunidad).subscribe(
      data => {
        this.actividades = data;
      },
      error => {
        console.log("cargarActividades: no se pudieron recuperar datos. " + error);
      }
    );
  } 

  cargarCuestionario(idunidad: number, idusuario: number): any {
    return this.activitiesService.getQuestions(idunidad, idusuario).subscribe(
      data => {
        this.preguntas = data;
      },
      error => {
        console.log("cargarCuestionario: no se pudieron recuperar datos. " + error);
      }
    );
  }  

  verificarRespuesta(idactividad:number,idpregunta:number, respuesta:number){

    let opcionselect = $('input[name="'+idpregunta+'"]:checked').val();
    console.log("ID curso: " + this.curso + " ID unidad: " + this.unidad );
    console.log("ID actividad: " + idactividad + " ID pregunta: " + idpregunta + " Opcion seleccionada: " + opcionselect);
    console.log("Respuesta correcta: " + respuesta);
    console.log(this.usuario + ","+ this.curso +","+ this.unidad +","+ idactividad +","+ idpregunta +","+ opcionselect +","+ respuesta);

    var elemento = document.getElementById('mensaje-'+idpregunta);
    var mensaje = "";
    if(opcionselect == respuesta){
      elemento!.innerHTML = '<div class="alert alert-success" role="alert"><p>Tu respuesta fue Correcta !!!</p></div>';
    }else{
      elemento!.innerHTML = '<div class="alert alert-danger" role="alert"><p>La respuesta no es correcta. Vuelve a intentarlo!</p></div>';
    }
    
    let incidence = {
      id: 0, usuario: this.usuario, curso: this.curso, unidad: this.unidad, 
      actividad: idactividad, pregunta: idpregunta, respuesta, opcionselect
    };
    
    this.activitiesService.saveIncidence(incidence).subscribe(
      data => {
        console.log(data);
        
        setTimeout(() =>{
          elemento!.innerHTML = "";
          this.cargarCuestionario(this.unidad!,this.usuario);
        }, 3000);    
        
        

      },
      error => {
        console.log("verificarRespuesta: no se pudieron grabar los datos. " + error);
      }
    );    

  }

  test(){
    var elemento = document.getElementById('mensaje-1');
    elemento!.innerHTML = "<p>HOLAAAAAA</p>";

  }

  regresar() {
      this.router.navigateByUrl("/dashboard/units/"+this.curso);      
  }    

}


        // preguntas_opciones
        // var datosjason = JSON.parse(JSON.stringify(data));
        // for (let i = 0; i < datosjason.length; i++) {
        //   if (datosjason[i].estado == 1) {
        //     this.tarjetasHabilitadas[i] = true;
        //   }
        // }