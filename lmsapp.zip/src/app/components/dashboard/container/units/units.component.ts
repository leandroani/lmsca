import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UnitsService } from './units.service';

// Esta declaracion es importante para que dal la funcionalidad de JQuery.
declare var $: any;

@Component({
  selector: 'app-units',
  templateUrl: './units.component.html',
  styleUrls: ['./units.component.css']
})
export class UnitsComponent implements OnInit {

  idcurso: string | undefined;
  unidades: any = [];
  tarjetasHabilitadas: boolean[] = [true, false, false, false];

  constructor(private _router: ActivatedRoute, private router: Router, private unitsService: UnitsService) {
  }

  ngOnInit(): void {
    this.idcurso = this._router.snapshot.paramMap.get('id')?.toString();
    var curso = parseInt(this.idcurso!);
    var usuario = 1; // el Id lo deveria rescatar desde el localStorage.getItem("xxxx")
    this.cargarUnidadesPorCursoyUsuario(curso, usuario);
  }

  cargarUnidadesPorCursoyUsuario(idcurso: number, idusuario: number): any {
    return this.unitsService.getUnitsByCourses(idcurso, idusuario).subscribe(
      data => {
        this.unidades = data;
      },
      error => {
        console.log("cargarUnidadesPorCursos: no se pudieron recuperar datos. " + error);
      }
    );
  }

  mostrarUnidad(unidad: any) {
    console.log("Component Unit= Curso " + this.idcurso + " con Contenido de la unidad: " + unidad);
    this.router.navigateByUrl("/dashboard/activities/" + this.idcurso + "/" + unidad);

  }

  regresar() {
    this.router.navigateByUrl("/dashboard/courses");
  }  

}
