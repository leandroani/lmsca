import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UnitsService {

  constructor(private http: HttpClient) { }

  getUnitsByCourses(idcurso: number, idusuario: number): Observable<any> {
    return this.http.get(environment.URL + "/unitsbycourse/"+idcurso+"/"+idusuario);
  }  

  getUnitAll(idusuario: number): Observable<any> {
    return this.http.get(environment.URL + "/unitsall/"+idusuario);
  }

}
