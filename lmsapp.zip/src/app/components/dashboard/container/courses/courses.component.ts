import { Component, HostListener, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CoursesService } from './courses.service';

@Component({
  selector: 'app-courses',
  templateUrl: './courses.component.html',
  styleUrls: ['./courses.component.css']
})


export class CoursesComponent implements OnInit {

  cursos: any = [];

  constructor(private _router: ActivatedRoute, private router: Router, private coursesService: CoursesService) { 
    
  }

  ngOnInit() {
    
    this.cargarCursosPorUsuario();

  }

  cargarCursosPorUsuario(): any {
    let user = 1;  // el Id lo deveria rescatar desde el localStorage.getItem("xxxx")

    return this.coursesService.getCoursesByUser(user).subscribe(
      data => {
        this.cursos = data;
      },
      error => {
        console.log("cargarCursosPorUsuario: no se pudieron recuperar datos. " + error);
      }
    );
  }
  
  mostrarCursos(json: any) {
    console.log("preciono el boton!");
    var datosjason = JSON.parse(JSON.stringify(json));
    for (let i = 0; i < datosjason.length; i++) {
      console.log("valores: " + datosjason[i].nombre)
    }
  }

  onClick(event: MouseEvent): void {
    event.preventDefault();
    console.log('myMethod working!!!' + event.target);
    // Para evitar la propagación del evento click.
    event.stopPropagation();
    // Obtengo el ultimo parametro de la url que viene desde 
    // routerLink que en este caso seria el Id del curso
    if (event.target instanceof HTMLElement) {
      const href = event.target.getAttribute('href');
      if (href) {
        const segments = href.split('/');
        const idcurso = segments[segments.length - 1];
        console.log('Curso Número:', idcurso);
        this.router.navigateByUrl("/dashboard/units/" + idcurso);
      }
    }
  }

  regresar() {
    this.router.navigateByUrl("/dashboard/welcome");
  }  


}

