import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';

// Esta declaracion es importante para que dal la funcionalidad de JQuery.
declare var $: any;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {


  constructor(public loginService: LoginService, public router: Router) { }

  ngOnInit() {
    //Toggle Click Function
    $("#menu-toggle").click(function (e: { preventDefault: () => void; }) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  }


}
