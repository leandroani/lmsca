import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { LoginService } from "../../services/login.service";

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  username: string = "";
  password: string = "";


  constructor(public loginService: LoginService, public router: Router) { }

  ngOnInit(): void { }

  login() {
    const credentials = { username: this.username, password: this.password };
    this.loginService.login(credentials).subscribe(
      jsonResponse => {        
        if(jsonResponse.estado == 200){
          console.log(jsonResponse.detalle);
          //localStorage.setItem("token", jsonResponse.access_token);
          this.router.navigateByUrl("/dashboard/welcome");
        }
      },
      error => {
        console.log(error);
        this.router.navigateByUrl("/");
      }
    );
  }

}
