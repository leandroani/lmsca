import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, throwError } from "rxjs";
import { environment } from '../../../environments';


@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private http: HttpClient) { }

  login(user: any): Observable<any> {
    var formData: any = new FormData();
    formData.append('username', user.username);
    formData.append('password', user.password);
    return this.http.post(environment.URL + "/auth", formData);
  }


  // getCompanies(): Observable<any> {
  //   return this.http.get(environment.URL + "/adm/empresas");
  // }


}
