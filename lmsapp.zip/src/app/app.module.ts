import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { JwtHelperService,JWT_OPTIONS } from '@auth0/angular-jwt';
import { AuthGuardService } from './services/auth-guard.service';
import { AuthService } from './services/auth.service';
import { NavComponent } from './components/shared/nav/nav.component';
import { FooterComponent } from './components/shared/footer/footer.component';
import { WelcomeComponent } from './components/dashboard/container/welcome/welcome.component';
import { CoursesComponent } from './components/dashboard/container/courses/courses.component';
import { ActivitiesComponent } from './components/dashboard/container/activities/activities.component';
import { UnitsComponent } from './components/dashboard/container/units/units.component';
import { AdminpanelComponent } from './components/adminpanel/adminpanel.component';
import {DragDropModule} from '@angular/cdk/drag-drop';
import { AdmincoursesComponent } from './components/adminpanel/container/admincourses/admincourses.component';
import { AdminunitsComponent } from './components/adminpanel/container/adminunits/adminunits.component';
import { AdminactivitiesComponent } from './components/adminpanel/container/adminactivities/adminactivities.component';
import { AdminquestionnaireComponent } from './components/adminpanel/container/adminquestionnaire/adminquestionnaire.component';
import { AdminusersComponent } from './components/adminpanel/container/adminusers/adminusers.component';
import { AdminreportsComponent } from './components/adminpanel/container/adminreports/adminreports.component';


@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    DashboardComponent,
    NavComponent,
    FooterComponent,
    WelcomeComponent,
    CoursesComponent,
    ActivitiesComponent,
    UnitsComponent,
    AdminpanelComponent,
    AdmincoursesComponent,
    AdminunitsComponent,
    AdminactivitiesComponent,
    AdminquestionnaireComponent,
    AdminusersComponent,
    AdminreportsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    DragDropModule
  ],
  providers: [AuthGuardService, AuthService , { provide: JWT_OPTIONS, useValue: JWT_OPTIONS }, JwtHelperService ],
  bootstrap: [AppComponent],
  
})
export class AppModule { }
