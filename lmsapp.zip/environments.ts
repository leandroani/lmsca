export const environment = {
    PRODUCTION: true,
    URL: 'http://localhost/api/index.php'
}
