import { NgModule } from '@angular/core';
import { RouterModule, Routes, CanActivate } from '@angular/router';
import { AuthGuardService as AuthGuard } from './services/auth-guard.service';
import { LoginComponent } from './components/login/login.component';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { WelcomeComponent } from './components/dashboard/container/welcome/welcome.component';
import { CoursesComponent } from './components/dashboard/container/courses/courses.component';
import { ActivitiesComponent } from './components/dashboard/container/activities/activities.component';
import { UnitsComponent } from './components/dashboard/container/units/units.component';
import { AdminpanelComponent } from './components/adminpanel/adminpanel.component';
import { AdmincoursesComponent  } from './components/adminpanel/container/admincourses/admincourses.component';
import { AdminunitsComponent  } from './components/adminpanel/container/adminunits/adminunits.component';
import { AdminactivitiesComponent  } from './components/adminpanel/container/adminactivities/adminactivities.component';
import { AdminquestionnaireComponent  } from './components/adminpanel/container/adminquestionnaire/adminquestionnaire.component';
import { AdminusersComponent  } from './components/adminpanel/container/adminusers/adminusers.component';
import { AdminreportsComponent  } from './components/adminpanel/container/adminreports/adminreports.component';
import { ExperienceComponent } from './components/dashboard/container/experience/experience.component';
import { AboutComponent } from './components/dashboard/container/about/about.component';

const routes: Routes = [

  { path: "", component: LoginComponent, pathMatch: "full" },

  { path: "login", component: LoginComponent },


  // dashboard con subrutas
  {
    path: "dashboard", component: DashboardComponent,  canActivate: [AuthGuard],
    children: [
      { path: "welcome", component: WelcomeComponent },
      { path: "courses", component: CoursesComponent },
      { path: "courses/:id", component: CoursesComponent },
      { path: "units/:id", component: UnitsComponent },
      { path: "activities/:idcurso/:idunit", component: ActivitiesComponent },
      { path: "experience", component: ExperienceComponent },
      { path: "about", component: AboutComponent }
    ]
  },


  // panel Admin con subrutas
  {
    path: "manager", component: AdminpanelComponent, canActivate: [AuthGuard],
    children: [
      { path: "courses", component: AdmincoursesComponent },
      { path: "units", component: AdminunitsComponent },
      { path: "activities", component: AdminactivitiesComponent },
      { path: "questionnaire", component: AdminquestionnaireComponent },
      { path: "users", component: AdminusersComponent },
      { path: "reports", component: AdminreportsComponent }
    ]
  },  

  { path: '**', redirectTo: '' }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

