import { Injectable } from '@angular/core';
import { Router, CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { JwtHelperService } from '@auth0/angular-jwt';

@Injectable({
  providedIn: 'root'
})
export class AuthGuardService implements CanActivate {

  constructor(private router: Router, private jwtHelper: JwtHelperService) { }

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): boolean | UrlTree {
    
    let token;
    
    if (typeof localStorage !== 'undefined' && localStorage.getItem('token') !== null) {      
       token = localStorage.getItem('token');
    }

    if (token && !this.jwtHelper.isTokenExpired(token)) {
      // Token válido y no expirado, permite la navegación
      return true;
    } else {
      // Token inválido o expirado, redirige a la página de login
      return this.router.createUrlTree(['/login']);
    }
  }

}
