import { Component, OnInit } from '@angular/core';
import { Router } from "@angular/router";
import { LoginService } from "../../services/login.service";

import { JwtHelperService } from '@auth0/angular-jwt';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {

  username: string = "";
  password: string = "";


  constructor(public loginService: LoginService, public router: Router, private jwtHelper: JwtHelperService) { }

  ngOnInit(): void { 

    if (typeof localStorage !== 'undefined' && localStorage.getItem('token') !== null) {
      localStorage.removeItem('token');
      localStorage.removeItem('id');
      localStorage.removeItem('username');
      localStorage.removeItem('rol');
    }
  }

  login() {
    const credentials = { username: this.username, password: this.password };

    this.loginService.authenticate(credentials).subscribe(
      jsonResponse => {        
        if(jsonResponse.data['estado'] == 401){ 
          var elemento = document.getElementById('mensajeLogin');   
          elemento!.innerHTML = '<div class="alert alert-danger" role="alert"><p>Credenciales inválidas.</p></div>';     
          setTimeout(() => {
            elemento!.innerHTML = "";
          }, 3000);          
        }else{
          if(jsonResponse.estado == 200){    

            // Autenticación exitosa
            const token = jsonResponse.data['access_token'];
                
            // Almacena el token en el localStorage y otros datos necesarios
            const datosDelToken = this.obtenerDatosDesdeToken(token);
            localStorage.setItem('token', token);
            localStorage.setItem('id', datosDelToken['IDUser']);
            localStorage.setItem('username', datosDelToken['NombreUsuario']);        
            localStorage.setItem('rol', datosDelToken['rol']);
            
            const isTokenExpired = this.jwtHelper.isTokenExpired(token);
            console.log('¿Token expirado?', isTokenExpired);

            // Redirecciona a la página Home
            if(datosDelToken['rol']=='user'){
              this.router.navigateByUrl("/dashboard/welcome");
            }else{
              this.router.navigateByUrl("/" + datosDelToken['rol']);
            }
          }                   
        }
      },
      error => {
        alert("Error de conexion "+error);        
        console.log(error);
        this.router.navigateByUrl("/");
      }
    );
  }


  obtenerDatosDesdeToken(token:string) {
    // Separar el token en sus partes
    const [encabezadoBase64, payloadBase64, firmaBase64] = token.split('.');

    // Decodificar la parte del payload
    const payload = JSON.parse(atob(payloadBase64));

    return payload;
  }

  test(){
    alert("HOLA");
  }

}
