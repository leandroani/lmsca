import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';

// Esta declaracion es importante para que dal la funcionalidad de JQuery.
declare var $: any;

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent {

  idusuario: number = 0;

  reemplazos: any[] = [
    ['Ã¡', 'á'],
    ['Ã¤', 'ä'],
    ['Ã©', 'é'],
    ['í©', 'é'],
    ['Ã³', 'ó'],
    ['íº', 'ú'],
    ['Ãº', 'ú'],
    ['Ã±', 'ñ'],
    ['í‘', 'Ñ'],
    ['Ã', 'í'],
    ['â€“', '–'],
    ['â€™', '\''],
    ['â€¦', '...'],
    ['â€“', '-'],
    ['â€œ', '"'],
    ['â€', '"'],
    ['â€˜', '\''],
    ['â€¢', '-'],
    ['â€¡', 'c'],
    ['Â', '']
  ];


  constructor(public loginService: LoginService, public router: Router) { }

  ngOnInit() {

    this.idusuario = parseInt(localStorage.getItem('id')!);

    //Toggle Click Function
    $("#menu-toggle").click(function (e: { preventDefault: () => void; }) {
      e.preventDefault();
      $("#wrapper").toggleClass("toggled");
    });
  }

  aplicarConversion(textoUnicode: string, reemplazos: any[]): string {
    if (textoUnicode !== undefined){
      reemplazos.forEach(par => {
        textoUnicode = textoUnicode.replace(new RegExp(par[0], 'g'), par[1]);
      });
    }
    return textoUnicode;
  }	

}
