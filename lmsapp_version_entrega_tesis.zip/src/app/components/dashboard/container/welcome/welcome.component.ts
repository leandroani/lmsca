import { Component } from '@angular/core';

@Component({
  selector: 'app-welcome',
  templateUrl: './welcome.component.html',
  styleUrls: ['./welcome.component.css']
})
export class WelcomeComponent {

  idusuario: number = 0;

  constructor(){}

  
  ngOnInit() {

    this.idusuario = parseInt(localStorage.getItem('id')!);
  }  


  
}
