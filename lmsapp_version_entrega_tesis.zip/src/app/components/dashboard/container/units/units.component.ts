import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { UnitsService } from './units.service';
import { CoursesService} from '../courses/courses.service';
import { DashboardComponent } from '../../dashboard.component';


// Esta declaracion es importante para que dal la funcionalidad de JQuery.
declare var $: any;

@Component({
  selector: 'app-units',
  templateUrl: './units.component.html',
  styleUrls: ['./units.component.css']
})
export class UnitsComponent implements OnInit {
  
  usuario: number = 0;
  idcurso: string | undefined;
  nombrecurso:string | undefined;
  unidades: any = [];
  tarjetasHabilitadas: boolean[] = [true, false, false, false];

  constructor(private _router: ActivatedRoute, private router: Router, private unitsService: UnitsService, private coursesService:CoursesService,private dashboardComponent:DashboardComponent) {
    
  }

  ngOnInit(): void {
    this.idcurso = this._router.snapshot.paramMap.get('id')?.toString();
    var curso = parseInt(this.idcurso!);
    this.usuario = parseInt(localStorage.getItem('id')!);
    this.cargarCursosPorId(curso);
    this.cargarUnidadesPorCursoUsuario(curso, this.usuario);
  }

  cargarUnidadesPorCursoUsuario(idcurso: number, idusuario: number): any {
    return this.unitsService.getUnitsByCoursesAndUser(idcurso, idusuario).subscribe(
      data => {
        this.unidades = data;

        // Aplicar la función de conversión de caracteres especiales como los acentuados...
        this.unidades = data.map((item: { nombre: string; descripcion: string; }) => {
          item.nombre = this.dashboardComponent.aplicarConversion(item.nombre,this.dashboardComponent.reemplazos);
          item.descripcion = this.dashboardComponent.aplicarConversion(item.descripcion,this.dashboardComponent.reemplazos);
          return item;
        });         
      },
      error => {
        console.log("cargarUnidadesPorCursos: no se pudieron recuperar datos. " + error);
      }
    );
  }

  mostrarUnidad(unidad: any) {
    console.log("Component Unit= Curso " + this.idcurso + " con Contenido de la unidad: " + unidad);
    this.router.navigateByUrl("/dashboard/activities/" + this.idcurso + "/" + unidad);

  }

  cargarCursosPorId(idcurso: number): any {   
    return this.coursesService.getCoursesById(idcurso).subscribe(
      data => {
        this.nombrecurso = data[0].nombre;

        //Aplicar la función de conversión de caracteres especiales como los acentuados...
        this.nombrecurso = this.dashboardComponent.aplicarConversion(this.nombrecurso!,this.dashboardComponent.reemplazos);        
      },
      error => {
        console.log("cargarCursosPorId: no se pudieron recuperar datos. " + error);
      }
    );
  }  

  regresar() {
    this.router.navigateByUrl("/dashboard/courses");
  }  

}
