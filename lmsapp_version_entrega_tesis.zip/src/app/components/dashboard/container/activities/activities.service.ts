import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ActivitiesService {

  constructor(private http: HttpClient) { }

  getStateUnits(idunidad: number,idusuario: number): Observable<any> {
    return this.http.get(environment.URL + "/stateunit/"+idunidad+"/"+idusuario);
  } 

  getActivitiesByUnit(idunidad: number): Observable<any> {
    return this.http.get(environment.URL + "/activities/"+idunidad);
  }  

  getUnitsById(id: number): Observable<any> {
    return this.http.get(environment.URL + "/unidadbyid/"+id);
  }   

  getQuestions(idunidad: number,idusuario: number): Observable<any> {
    return this.http.get(environment.URL + "/questions/"+idunidad+"/"+idusuario);
  }  

  saveIncidence(incidence: any): Observable<any>{
    return this.http.post(environment.URL + "/incidence", JSON.stringify(incidence));    
  }

  // updateIncidene(incidence: any): Observable<any> {
  //   return this.http.post(environment.URL + "/incidence",JSON.stringify(incidence));
  // }   

}
