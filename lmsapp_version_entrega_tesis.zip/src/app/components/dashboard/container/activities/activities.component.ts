import { Component } from '@angular/core';
import { ActivatedRoute, Router} from '@angular/router';
import { ActivitiesService } from './activities.service';
import { DashboardComponent } from '../../dashboard.component';
// Esta declaracion es importante para que dal la funcionalidad de JQuery.
declare var $: any;

@Component({
  selector: 'app-activities',
  templateUrl: './activities.component.html',
  styleUrls: ['./activities.component.css']
})
export class ActivitiesComponent {
  
  private history: string[] = [];

  debug=false;
  idcurso: string | undefined;
  idunit: string | undefined;
  nombreunidad:string | undefined;
  unidad: number | undefined;
  curso: number | undefined;
  
  actividades: any = [];
  preguntas: any = [];
  preguntas_opciones: any = [];
  usuario:number=0;

  mostrar_todo:string='NO';

  showImage: boolean[] = Array(15).fill(true);
  
  constructor(private _router: ActivatedRoute, private router: Router, private activitiesService:ActivitiesService, private dashboardComponent:DashboardComponent) {

    this.usuario = parseInt(localStorage.getItem('id')!);

    this.idcurso = this._router.snapshot.paramMap.get('idcurso')?.toString(); 
    this.idunit = this._router.snapshot.paramMap.get('idunit')?.toString();  
    
    console.log("Debug: Component Activities= Curso " + this.idcurso + " con Contenido de la unidad: " + this.idunit);

    this.unidad = parseInt(this.idunit!);
    this.curso = parseInt(this.idcurso!);

    this.cargarEstadoUnidad(this.unidad!,this.usuario);        
    this.cargarNombreUnidad(this.unidad);
    this.cargarActividades(this.unidad);
    this.cargarCuestionario(this.unidad,this.usuario);
  }

  cargarEstadoUnidad(idunidad:number,idusuario:number): any {
    return this.activitiesService.getStateUnits(idunidad,idusuario).subscribe(
      data => {
        this.mostrar_todo = data[0].unidad_finalizada;
      },
      error => {
        console.log("cargarEstadoUnidad: no se pudieron recuperar datos. " + error);
      }
    );
  } 
  
  cargarNombreUnidad(idunidad:number): any {
    return this.activitiesService.getUnitsById(idunidad).subscribe(
      data => {
        this.nombreunidad = data[0].descripcion;
        
        //Aplicar la función de conversión de caracteres especiales como los acentuados...
        this.nombreunidad = this.dashboardComponent.aplicarConversion(this.nombreunidad!,this.dashboardComponent.reemplazos);
      },
      error => {
        console.log("cargarNombreUnidad: no se pudieron recuperar datos. " + error);
      }
    );
  } 

  cargarActividades(idunidad:number): any {
    return this.activitiesService.getActivitiesByUnit(idunidad).subscribe(
      data => {
        //this.actividades = data;
        
        // Aplicar la función de conversión de caracteres especiales como los acentuados...
        this.actividades = data.map((item: { nombre: string; descripcion: string; }) => {
          item.nombre = this.dashboardComponent.aplicarConversion(item.nombre,this.dashboardComponent.reemplazos);
          item.descripcion = this.dashboardComponent.aplicarConversion(item.descripcion,this.dashboardComponent.reemplazos);
          return item;
        });         
      },
      error => {
        console.log("cargarActividades: no se pudieron recuperar datos. " + error);
      }
    );
  } 

  cargarCuestionario(idunidad: number, idusuario: number): any {
    return this.activitiesService.getQuestions(idunidad, idusuario).subscribe(
      data => {
        //this.preguntas = data;

        // Aplicar la función de conversión de caracteres especiales como los acentuados...
        this.preguntas = data.map((item: { pregunta: string; descripcion: string; opcion1: string; opcion2: string; opcion3: string; opcion4: string; }) => {
          item.pregunta = this.dashboardComponent.aplicarConversion(item.pregunta,this.dashboardComponent.reemplazos);
          item.opcion1 = this.dashboardComponent.aplicarConversion(item.opcion1,this.dashboardComponent.reemplazos);
          item.opcion2 = this.dashboardComponent.aplicarConversion(item.opcion2,this.dashboardComponent.reemplazos);
          item.opcion3 = this.dashboardComponent.aplicarConversion(item.opcion3,this.dashboardComponent.reemplazos);
          item.opcion4 = this.dashboardComponent.aplicarConversion(item.opcion4,this.dashboardComponent.reemplazos);
          return item;
        });  

      },
      error => {
        console.log("cargarCuestionario: no se pudieron recuperar datos. " + error);
      }
    );
  }  

  verificarRespuesta(idactividad:number,idpregunta:number, respuesta:number){

    let opcionselect = $('input[name="'+idpregunta+'"]:checked').val();
    console.log("ID curso: " + this.curso + " ID unidad: " + this.unidad );
    console.log("ID actividad: " + idactividad + " ID pregunta: " + idpregunta + " Opcion seleccionada: " + opcionselect);
    console.log("Respuesta correcta: " + respuesta);
    console.log(this.usuario + ","+ this.curso +","+ this.unidad +","+ idactividad +","+ idpregunta +","+ opcionselect +","+ respuesta);

    var elemento = document.getElementById('mensaje-'+idpregunta);
    if(opcionselect == respuesta){
      elemento!.innerHTML = '<div class="alert alert-success" role="alert"><p>Tu respuesta fue Correcta !!!</p></div>';
    }else{
      elemento!.innerHTML = '<div class="alert alert-danger" role="alert"><p>La respuesta no es correcta. Vuelve a intentarlo!</p></div>';
    }
    
    let incidence = {
      id: 0, usuario: this.usuario, curso: this.curso, unidad: this.unidad, 
      actividad: idactividad, pregunta: idpregunta, respuesta, opcionselect
    };
    
    this.activitiesService.saveIncidence(incidence).subscribe(
      data => {
        console.log(data);

        setTimeout(() =>{
          this.cargarEstadoUnidad(this.unidad!,this.usuario);        
        }, 2000);  

        setTimeout(() =>{
          elemento!.innerHTML = "";        
          this.cargarActividades(this.unidad!);
        }, 3000);    
      
        setTimeout(() =>{
          elemento!.innerHTML = "";        
          this.cargarCuestionario(this.unidad!,this.usuario);
        }, 3000);    
               
      },
      error => {
        console.log("verificarRespuesta: no se pudieron grabar los datos. " + error);
      }
    );    

  }

  regresar() {
      this.router.navigateByUrl("/dashboard/units/"+this.curso);      
  }  
  
  getFileExtension(filename: string) {
    return filename.slice((filename.lastIndexOf(".") - 1 >>> 0) + 2);
  }  

  toggleView(i:any) {
    this.showImage[i] = false;
  }  

}


        // preguntas_opciones
        // var datosjason = JSON.parse(JSON.stringify(data));
        // for (let i = 0; i < datosjason.length; i++) {
        //   if (datosjason[i].estado == 1) {
        //     this.tarjetasHabilitadas[i] = true;
        //   }
        // }