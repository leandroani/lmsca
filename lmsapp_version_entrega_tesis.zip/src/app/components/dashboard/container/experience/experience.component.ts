import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ExperienceService } from './experience.service';
declare var $: any;


@Component({
  selector: 'app-experience',
  templateUrl: './experience.component.html',
  styleUrls: ['./experience.component.css']
})
export class ExperienceComponent {

  public myformMensaje!: FormGroup;
  public myformEncuesta!: FormGroup;
  mensajes: any = [];
  selectedOptions: number[] = new Array(15).fill(0);


  constructor(private formBuilder: FormBuilder, private experienceService:ExperienceService){}

  ngOnInit() {

    this.cargarMensajes();

    this.myformMensaje = this.formBuilder.group({
      messajeFormControlTextarea: ['', [Validators.required, Validators.minLength(10)]]
    });

    this.myformEncuesta = this.formBuilder.group({
      titleFormControlInput: ['', [Validators.required, Validators.minLength(2)]],
      descriptionFormControlTextarea: ['', [Validators.required, Validators.minLength(2)]],
      imagen: ['', [Validators.required]]
    });
  }


  cargarMensajes(): any {      

    return this.experienceService.getMessages().subscribe(
      data => {
        this.mensajes = data;
      },
      error => {
        console.log("cargarMensajes: no se pudieron recuperar datos. " + error);
      }
    );
  }

  saveMessaje(){
    
    var text = this.myformMensaje.get("messajeFormControlTextarea")?.value;
    var mensaje = { "mensaje": text};    
    
    var elemento = document.getElementById('mensaje-enviado');

    this.experienceService.saveMessages(mensaje).subscribe(
        data => {            
              if (data['data'].estado == "OK") {
                elemento!.innerHTML = '<div class="alert alert-success" role="alert"><p>Mensaje enviado!!!</p></div>';
                setTimeout(() => {
                  elemento!.innerHTML = "";
                  this.cargarMensajes();
                  this.myformMensaje.reset();
                }, 3000);
              }
            },
            error => {
              console.log("saveMessaje: no se pudieron recuperar datos. " + error);
            }
    );
  }

  saveQuizzes(){ 

    // console.log('Opciones seleccionadas:', this.selectedOptions);
    // console.log("VAlor:" + this.selectedOptions[0]);
    // var e1a = (this.selectedOptions[0]>0) ? 9 : 0;
    // console.log("VAlor:" + e1a);
    // this.selectedOptions = [] = new Array(15).fill(0);;
    
    var elemento = document.getElementById('encuesta-enviada');

    var encuesta = { "valores": this.selectedOptions};    
    this.experienceService.saveQuizzes(encuesta).subscribe(
        data => {            
              if (data['data'].estado == "OK") {
                this.selectedOptions = [] = new Array(15).fill(0);

                elemento!.innerHTML = '<div class="alert alert-success" role="alert"><p>Encuesta enviada!!!</p></div>';
                setTimeout(() => {
                  elemento!.innerHTML = "";
                }, 3000);                

              }
            },
            error => {
              console.log("saveQuizzes: no se pudieron recuperar datos. " + error);
            }
    );





//     var e1m = this.myformEncuesta.get("cuestionario1M")?.value;
//     var e1b = this.myformEncuesta.get("cuestionario1B")?.value;
//     var e2a = this.myformEncuesta.get("cuestionario2A")?.value;
//     var e2m = this.myformEncuesta.get("cuestionario2M")?.value;
//     var e2b = this.myformEncuesta.get("cuestionario2B")?.value;
//     var e3a = this.myformEncuesta.get("cuestionario3A")?.value;
//     var e3m = this.myformEncuesta.get("cuestionario3M")?.value;
//     var e3b = this.myformEncuesta.get("cuestionario3B")?.value;
//     var e4a = this.myformEncuesta.get("cuestionario4A")?.value;
//     var e4m = this.myformEncuesta.get("cuestionario4M")?.value;
//     var e4b = this.myformEncuesta.get("cuestionario4B")?.value;
//     var e5a = this.myformEncuesta.get("cuestionario5A")?.value;
//     var e5m = this.myformEncuesta.get("cuestionario5M")?.value;
//     var e5b = this.myformEncuesta.get("cuestionario5B")?.value;

//     var encuesta = { "e1a": e1a, "e1m": e1m, "e1b": e1b , 
//                     "e2a": e2a, "e2m": e2m, "e2b": e2b , 
//                     "e3a": e3a, "e3m": e3m, "e3b": e3b , 
//                     "e4a": e4a, "e4m": e4m, "e4b": e4b , 
//                     "e5a": e5a, "e5m": e5m, "e5b": e5b  
//                   };    
// console.log("XXXXXXXXXXXXXXXXXXXXXXXXXX");                  
// console.log("e1a:"+e1a + "e2a:"+e2a + " e3a:" + e3a);




    

  }

}
