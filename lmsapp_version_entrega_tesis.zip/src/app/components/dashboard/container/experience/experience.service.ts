import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class ExperienceService {

  constructor(private http: HttpClient) { }

  getMessages(): Observable<any> {
    return this.http.get(environment.URL + "/messages");
  }  

  saveMessages(param: any): Observable<any>{
    return this.http.post(environment.URL + "/messages", JSON.stringify(param));    
  }  

  saveQuizzes(param: any): Observable<any>{
    return this.http.post(environment.URL + "/quizzes", JSON.stringify(param));    
  }
    
}
