import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CoursesService {

 
  constructor(private http: HttpClient) { }


  getCoursesByUser(id: number): Observable<any> {
    return this.http.get(environment.URL + "/coursesbyuser/"+id);
  }  

  getCoursesById(id: number): Observable<any> {
    return this.http.get(environment.URL + "/coursesbyid/"+id);
  }   

}
