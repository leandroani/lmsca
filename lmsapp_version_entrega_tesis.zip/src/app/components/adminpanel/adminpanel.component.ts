import { Component } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { AdminpanelService } from './adminpanel.service';

@Component({
  selector: 'app-adminpanel',
  templateUrl: './adminpanel.component.html',
  styleUrls: ['./adminpanel.component.css']
})
export class AdminpanelComponent {

  public cursos: any = [];

  constructor(private adminpanelService: AdminpanelService) {

    this.cargarTodosLosCursos().subscribe(
      (data: any) => {
        this.cursos = data;
      },
      (error: string) => {
        console.log("cargarTodosLosCursos: no se pudieron recuperar datos. " + error);
      }
    );    
    
  }

  obtenerCursos(){
    return this.cursos;
  }
  
  obtenerCursosUsuarios(): any {
    return this.adminpanelService.getCoursesUsers();
  }

  cargarTodosLosUsuarios(): any {
    return this.adminpanelService.getUsersAll();
  } 

  guardarUsuario(usuario:any) {
    return this.adminpanelService.saveUser(usuario);
  }

  cargarTodosLosCursos(): any {
    return this.adminpanelService.getCoursesAll();
  }

  guardarCurso(curso:any){
    return this.adminpanelService.saveCourse(curso);    
  }

  modificarCurso(curso:any){
    return this.adminpanelService.updateCourse(curso);    
  }  

  guardarUsuarioPorCurso(parametros:any){
    return this.adminpanelService.saveUserByCourse(parametros);    
  }

  cargarTodosLasUnidadesPorCurso(idcurso:string): any {
    return this.adminpanelService.getUnitsByCourses(idcurso);
  }

  guardarUnidad(unit:any){
    return this.adminpanelService.saveUnit(unit);    
  }

  modificarUnidad(unidad:any){
    return this.adminpanelService.updateUnit(unidad);    
  }  

  cargarTodosLasActividadesPorUnidad(idunidad:string): any {
    return this.adminpanelService.getActivitiesByUnit(idunidad);
  }

  guardarActividad(activity:any){
    return this.adminpanelService.saveActivity(activity);    
  }

  modificarActividad(actividad:any){
    return this.adminpanelService.updateActivity(actividad);    
  }   

  cargarCuestionarioPorActividad(idunidad:string,idactividad:string): any {
    return this.adminpanelService.getQuestionaryByActivity(idunidad,idactividad);
  }

  guardarCuestionario(questionary:any){
    return this.adminpanelService.saveQuestionary(questionary);    
  }

  modificarCuestionario(questionary:any){
    return this.adminpanelService.updateQuestionary(questionary);    
  } 

  uploadFile(myFiles: any){
    return this.adminpanelService.uploadFile(myFiles);
  }

  cargarIncidenciasPorUsuarios(): any {
    return this.adminpanelService.getIncidences();
  }

  cargarDatosGraficoParticipacion(): any {
    return this.adminpanelService.getDataGraphParticipation();
  }

  cargarDatosEncuestas(): any {
    return this.adminpanelService.getDataQuizzes();
  }

  cargarDatosPorcCursoRealizado(): any {
    return this.adminpanelService.getDataPorcCourseCompleted();
  }  

  aplicarConversion(textoUnicode: string): string {

    const reemplazos = [
      ['Ã¡', 'á'],
      ['Ã¤', 'ä'],
      ['Ã©', 'é'],
      ['í©', 'é'],
      ['Ã³', 'ó'],
      ['íº', 'ú'],
      ['Ãº', 'ú'],
      ['Ã±', 'ñ'],
      ['í‘', 'Ñ'],
      ['Ã', 'í'],
      ['â€“', '–'],
      ['â€™', '\''],
      ['â€¦', '...'],
      ['â€“', '-'],
      ['â€œ', '"'],
      ['â€', '"'],
      ['â€˜', '\''],
      ['â€¢', '-'],
      ['â€¡', 'c'],
      ['Â', '']
    ];    
    if (textoUnicode !== undefined){
      reemplazos.forEach(par => {
        textoUnicode = textoUnicode.replace(new RegExp(par[0], 'g'), par[1]);
      });
    }
    return textoUnicode;
  }	


}
