import { Component, ChangeDetectionStrategy, ViewChild, ElementRef } from '@angular/core';
import { AdminpanelComponent } from '../../adminpanel.component';
import { environment } from 'environments';
import { AdminpanelService } from '../../adminpanel.service';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';


@Component({
  selector: 'app-admincourses',
  templateUrl: './admincourses.component.html',
  styleUrls: ['./admincourses.component.css']
})
export class AdmincoursesComponent {

  public myform!: FormGroup;
  public msgLoadFiles: string = "";
  public urlapp: string = environment.URL + "/upload/";
  public fileList: File[] = [];
  public cursos: any = [];

  public page = 1;
  public tableSize = 5;
  public count = 0;

  public contenido!: string;
  public isChecked:boolean = true;

  @ViewChild('myTable')
  myTable!: ElementRef;

  @ViewChild('myInput')
  myInput!: ElementRef;
  myGroup: FormGroup<{ firstName: FormControl<any>; }>;


  constructor(private adminpanelComponent: AdminpanelComponent, private adminpanelService: AdminpanelService, private formBuilder: FormBuilder) {

    this.myform = this.formBuilder.group({
      title: ['', [Validators.required, Validators.minLength(2)]],
      description: ['', [Validators.required, Validators.minLength(2)]],
      imagen: ['', [Validators.required]]
    });

    this.myGroup = new FormGroup({
      firstName: new FormControl()
    });

  }

  ngOnInit() {

    this.getCourses();

  }

  getCourses(): any {

    return this.adminpanelComponent.cargarTodosLosCursos().subscribe(
      (data: any) => {
        this.cursos = data;
      },
      (error: string) => {
        console.log("getCourses: no se pudieron recuperar datos. " + error);
      }
    );
  }

  saveCourse() {
    var title = this.myform.get("title")?.value;
    var description = this.myform.get("description")?.value;
    var imagen = this.myform.get("imagen")?.value;
    var disponible = 1;
    imagen = '../assets/upload/' + imagen;
    if(!this.isChecked){
      disponible = 0;
    }
    var curso = { "title": title, "description": description, "imagen": imagen , "disponible":disponible};
    this.adminpanelComponent.guardarCurso(curso).subscribe(
      data => {
        var elemento = document.getElementById('mensaje');
        if (data['data'].estado == "OK") {
          elemento!.innerHTML = '<div class="alert alert-success" role="alert"><p>Se creo un nuevo curso!!!</p></div>';
        } else {
          elemento!.innerHTML = '<div class="alert alert-danger" role="alert"><p>No fue posible crear un curso!</p></div>';
        }
        setTimeout(() => {
          elemento!.innerHTML = "";
          this.myform.reset();
          this.getCourses();
        }, 3000);
      },
      error => {
        console.log("saveCourse: no se pudieron recuperar datos. " + error);
      }
    );
  }

  onFileSelected(event: any) {
    this.fileList = [];
    for (var i = 0; i <= event.target.files.length - 1; i++) {
      var selectedFile = event.target.files[i];
      console.log("Nombre del archivo: " + selectedFile.name);
      this.fileList.push(selectedFile);
    }
    this.adminpanelComponent.uploadFile(this.fileList).subscribe(response => {
      if (response.estado == "ok") {
        this.msgLoadFiles = "Archivo seleccionado con exito!";
        this.myform.controls['imagen'].setValue(response.urls);
        // muestro la imagen seleccionada
        var imagen = '../assets/upload/' + response.urls;
        console.log("Nuevo nombre del archivo imagen cargado...: " + imagen);
        var elemento = document.createElement("img");
        elemento.setAttribute("src", imagen);
        elemento.setAttribute("width", "400px");
        elemento.setAttribute("height", "255px");
        var actual = document.getElementById('imagen_actual');
        actual!.appendChild(elemento);
      } else {
        this.msgLoadFiles = "Algo salio mal!";
      }
    });
  }

  myFunctionSearch(event: any): void {
    // console.log("PASO: " + event.target.value);
    var input, filter, table, tr, td, i, txtValue;
    filter = this.myInput.nativeElement.value.toUpperCase();
    tr = this.myTable.nativeElement.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[0];
      if (td) {
        txtValue = td.textContent || td.innerText;        
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

  onTableDataChange(event: number) {
    this.page = event;
  }

  onTableSizeChange(event: { target: { value: number; }; }): void {
    this.tableSize = event.target.value;
    this.page = 1;
  }

  checkValue(event: any){
    console.log(event + " " + this.isChecked );
  }

  detectarCambio(event: any,id:number) {
    // Verifica si la tecla presionada es "Enter"
    if (event.keyCode === 13) {
      // Acción a realizar cuando se presiona "Enter"
      var el1 = document.getElementById("inputName-"+id);
      var contenido1 = el1!.textContent;
      var el2 = document.getElementById("inputDescription-"+id);
      var contenido2 = el2!.textContent;
      var el3 = document.getElementById("inputImagen-"+id);
      var contenido3 = el3!.textContent;        
      var el4 = document.getElementById("inputDisable-"+id);
      var contenido4 = el4!.textContent;            
      var check = 1;
      console.log('Se presionó Enter en detectarCambio');
      if(!this.isChecked){
        check=0;
      }                 
      var curso = { "idcurso":id, "title": contenido1, "description": contenido2, "imagen": contenido3, "disponible":check };
      this.adminpanelComponent.modificarCurso(curso).subscribe(
        data => {
          if (data['data'].estado == "OK") {
            this.getCourses();
          }
        },
        error => {
          console.log("detectarCambio: no se pudieron recuperar datos. " + error);
        }
      );
    }
  }

}
