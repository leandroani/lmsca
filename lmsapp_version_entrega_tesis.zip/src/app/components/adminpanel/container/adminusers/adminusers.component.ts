import { Component } from '@angular/core';
import {AdminpanelComponent} from '../../adminpanel.component';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
declare var $: any;

@Component({
  selector: 'app-adminusers',
  templateUrl: './adminusers.component.html',
  styleUrls: ['./adminusers.component.css']
})
export class AdminusersComponent {
  
  public myform!: FormGroup;
  public myformAsig!: FormGroup;
  public usuarios: any = [];
  public cursos: any = [];
  public selected_user: string | undefined;
  public selectedUserInfoControl: FormControl<any>;
  public selected_courses: string | undefined;
  public selectedCourseInfoControl: FormControl<any>;

  constructor(private adminpanelComponent: AdminpanelComponent, private formBuilder: FormBuilder){
    
    this.myform = this.formBuilder.group({
      nameFormControlInput: ['', [Validators.required, Validators.minLength(2)]],
      passwordFormControlInput: ['', [Validators.required, Validators.minLength(2)]],
      emailFormControlInput: ['', [Validators.required]]      
    });

    this.selectedUserInfoControl = new FormControl();
    this.selectedCourseInfoControl = new FormControl();
    
  }

  ngOnInit() {

    this.myform.reset();

    this.getUsers();

    this.selectedUserInfoControl.valueChanges.subscribe(value => {
      this.selected_user = value;
    }); 

    this.selectedCourseInfoControl.valueChanges.subscribe(value => {
      this.selected_courses = value;
    });    
    
  }

  getUsers(): any {
    return this.adminpanelComponent.cargarTodosLosUsuarios().subscribe(
      (data: any) => {
        this.usuarios = data;
      },
      (error: string) => {
        console.log("getUsers: no se pudieron recuperar datos. " + error);
      }
    );
  }

  saveUser(){
    var nombre = this.myform.get("nameFormControlInput")?.value;
    var password = this.myform.get("passwordFormControlInput")?.value;
    var email = this.myform.get("emailFormControlInput")?.value;  
    
    var usuario = { "nombre": nombre, "password": password, "email":email};
    this.adminpanelComponent.guardarUsuario(usuario).subscribe(
        data => {
          var elemento = document.getElementById('mensajeUsuarioGuardado');
          if (data['data'].estado == "OK") {
            elemento!.innerHTML = '<div class="alert alert-success" role="alert"><p>Se creo un nuevo usuario!!!</p></div>';
          } else {
            elemento!.innerHTML = '<div class="alert alert-danger" role="alert"><p>No fue posible crear un usuario!</p></div>';
          }
          setTimeout(() => {
            elemento!.innerHTML = "";
            this.myform.reset();
            this.getUsers();
          }, 3000);
        },
        error=> {
          console.log("saveUser: no se pudieron recuperar datos. " + error);
        }
      );     
  }

  getCourses(): any {
    return this.cursos = this.adminpanelComponent.obtenerCursos();

  }

  assignCourseToUser(): any { 
    
    var param = { "iduser": this.selected_user, "idcourse": this.selected_courses};
    this.adminpanelComponent.guardarUsuarioPorCurso(param).subscribe(
      data => {
        var elemento = document.getElementById('mensajeUsuarioVinculado');
        if (data['data'].estado == "OK") {
          elemento!.innerHTML = '<div class="alert alert-success" role="alert"><p>Se vinculo usuario a curso!!!</p></div>';
        } else {
          elemento!.innerHTML = '<div class="alert alert-danger" role="alert"><p>No fue posible vincular el usuario al curso!</p></div>';
        }
        setTimeout(() => {
          elemento!.innerHTML = "";
          this.getUsers();
        }, 3000);
      },
      error=> {
        console.log("assignCourseToUser: no se pudieron recuperar datos. " + error);
      }
    );

  }   
    
  // Función para generar un hash SHA-256 de la contraseña
  generarHash(password: string) {
    
    // Crear un objeto TextEncoder
    const encoder = new TextEncoder();
    // Codificar la contraseña en formato UTF-8
    const data = encoder.encode(password);
    // Crear un hash usando la API de SubtleCrypto
    return crypto.subtle.digest('SHA-256', data)
      .then(buffer => {
        // Convertir el buffer a una cadena hexadecimal
        const hashArray = Array.from(new Uint8Array(buffer));
        const hashHex = hashArray.map(byte => byte.toString(16).padStart(2, '0')).join('');
        return hashHex;
      });
  }

}
