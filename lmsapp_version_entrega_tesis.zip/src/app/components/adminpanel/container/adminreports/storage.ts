// Inicio Grafico 1 nivel de dificultad de las actividades

export var niveldificultadstorage = [
    { name: "Alta", value: 3 }, //105000
    { name: "Media", value: 2 },  //55000 
    { name: "Baja", value: 1 } //15000
];


// Inicio Grafico 2 nivel de participacion de los estudiantes en los cursos.

export var participaccionstorage = [
    {
      "name": "Curso 1",
      "value": 8
    },
    {
      "name": "Curso 2",
      "value": 5
    },
    {
      "name": "Curso 3",
      "value": 3
    },
      {
      "name": "Curso 4",
      "value": 10
    },
    {
    "name": "Curso 5",
    "value": 7
  }
  ];


// Inicio Grafico 3 Satisfaccion del curso.

export var satisfaccionstorage = [
    {
      "name": "Opiniones",
      "series": [
        {
          "name": "Bueno",
          "value": 7
        },
        {
          "name": "Regular",
          "value": 2
        },
        {
          "name": "Deficiente",
          "value": 1
        }
      ]
    }
  ];
  

  export var metododidacticostorage = [
    {
      "name": "Opiniones",
      "series": [
        {
          "name": "Bueno",
          "value": 7
        },
        {
          "name": "Regular",
          "value": 2
        },
        {
          "name": "Deficiente",
          "value": 1
        }
      ]
    }
  ];  


  export var metodoaprendizajestorage = [
    {
      "name": "Opiniones",
      "series": [
        {
          "name": "Bueno",
          "value": 7
        },
        {
          "name": "Regular",
          "value": 2
        },
        {
          "name": "Deficiente",
          "value": 1
        }
      ]
    }
  ];


//   Rúbrica de Satisfacción y Percepción del Aprendizaje
// 1. Organización del Curso:
// Excelente (5): La estructura del curso fue clara y fácil de seguir.
// Bueno (4): La organización del curso fue efectiva, pero con pequeñas mejoras posibles.
// Regular (3): La estructura del curso fue adecuada, pero algunas áreas podrían mejorarse.
// Deficiente (2): La organización del curso fue confusa en varios aspectos.
// Malo (1): La estructura del curso fue completamente desorganizada.
// 2. Material del Curso:
// Excelente (5): El material del curso fue relevante, actualizado y enriquecedor.
// Bueno (4): La mayoría del material del curso fue relevante y útil.
// Regular (3): Algunos elementos del material del curso no fueron completamente útiles.
// Deficiente (2): El material del curso carecía de relevancia y actualización.
// Malo (1): El material del curso fue inadecuado e inútil.
// 3. Metodología de Enseñanza:
// Excelente (5): Las metodologías utilizadas fueron efectivas, variadas y motivadoras.
// Bueno (4): La mayoría de las metodologías utilizadas fueron efectivas.
// Regular (3): Algunas metodologías no fueron completamente efectivas.
// Deficiente (2): Las metodologías utilizadas fueron en su mayoría ineficaces.
// Malo (1): Las metodologías de enseñanza fueron completamente ineficaces.
// 4. Desarrollo de Actividades:
// Excelente (5): Las actividades fueron desafiantes y contribuyeron significativamente al aprendizaje.
// Bueno (4): La mayoría de las actividades fueron apropiadas y contribuyeron al aprendizaje.
// Regular (3): Algunas actividades no fueron completamente relevantes o desafiantes.
// Deficiente (2): Las actividades no fueron apropiadas ni desafiantes.
// Malo (1): Las actividades fueron completamente inadecuadas e inútiles.
// 5. Retroalimentación del Instructor:
// Excelente (5): La retroalimentación fue detallada, constructiva y proporcionada de manera oportuna.
// Bueno (4): La retroalimentación fue útil, aunque podría haber sido más detallada en algunos casos.
// Regular (3): Alguna retroalimentación fue limitada o podría haberse proporcionado de manera más oportuna.
// Deficiente (2): La retroalimentación fue insuficiente o poco útil.
// Malo (1): No hubo retroalimentación del instructor.
// 6. Satisfacción Global:
// Excelente (5): Estoy muy satisfecho con mi experiencia en el curso.
// Bueno (4): Estoy satisfecho en su mayoría con mi experiencia en el curso.
// Regular (3): Mi satisfacción con la experiencia en el curso es mixta.
// Deficiente (2): Mi satisfacción con la experiencia en el curso es baja en general.
// Malo (1): Estoy muy insatisfecho con mi experiencia en el curso.
// 7. Percepción del Aprendizaje:
// Excelente (5): Siento que he aprendido mucho y que el curso fue valioso.
// Bueno (4): La mayoría de lo que aprendí fue valioso y útil.
// Regular (3): Algunos aspectos del curso me resultaron útiles, pero otros no.
// Deficiente (2): Siento que no he aprendido lo suficiente y que el curso no fue completamente valioso.
// Malo (1): No siento que haya aprendido nada y que el curso fue una pérdida de tiempo.
// 8. Recomendación del Curso:
// Sí (5): Recomendaría este curso a otros estudiantes.
// Probablemente Sí (4): Es probable que recomiende este curso a otros.
// Neutral (3): No tengo una opinión clara sobre recomendar o no el curso.
// Probablemente No (2): Es probable que no recomiende este curso a otros.
// No (1): No recomendaría este curso a otros estudiantes.