import { Component, ElementRef, ViewChild } from '@angular/core';
import {AdminpanelComponent} from '../../adminpanel.component';
import { LegendPosition } from '@swimlane/ngx-charts';

@Component({
  selector: 'app-adminreports',
  templateUrl: './adminreports.component.html',
  styleUrls: ['./adminreports.component.css']
})
export class AdminreportsComponent {

  public incidencias:any = [];
  public page = 1;
  public tableSize = 5;
  public count = 0;   
  public legendPosition: LegendPosition = LegendPosition.Below;

  public graphparticipation:any = [];
  public niveldificultadstorage!: any[];
  public participaccionstorage!: any[];   
  public satisfaccionstorage!: any[];
  public cursosterminadosstorage!: any[];
  public cursos!: any[];
  
  public encuesta1!: any[];
  public encuesta2!: any[];
  public encuesta3!: any[];
  public encuesta4!: any[];
  public encuesta5!: any[];
  
  @ViewChild('myTable')
  myTable!: ElementRef;

  @ViewChild('myInput')
  myInput!: ElementRef;
  
  // Configuracion para los graficos.
  colorScheme: any = {
    domain: ['#01a1b4', '#d8eb42', '#de7944', '#AAAAAA','#5AA454', '#A10A28', '#C7B42C']
  };
  gradient: boolean = true;
  showLegend: boolean = true;
  showLabels: boolean = true;
  isDoughnut: boolean = false;
  
  schemeType: string = 'linear';
  showXAxis: boolean = true;
  showYAxis: boolean = true;
  LegendPosition = LegendPosition.Below;
  
  showXAxisLabel1: boolean = true;
  showXAxisLabel2: boolean = true;
  showXAxisLabel3: boolean = true;
  showXAxisLabel4: boolean = true;
  showYAxisLabel1: boolean = true;
  showYAxisLabel2: boolean = true;
  showYAxisLabel3: boolean = true;
  showYAxisLabel4: boolean = true;

  yAxisLabel1: string = 'Organización del Curso';
  yAxisLabel2: string = 'Metodología de enseñanza';
  yAxisLabel3: string = 'Desarrollo de Actividades';
  yAxisLabel4: string = 'Percepción del aprendizaje';
  xAxisLabel1 = 'Población';
  xAxisLabel2 = 'Población';
  xAxisLabel3 = 'Población';
  xAxisLabel4 = 'Población';


  constructor(private adminpanelComponent:AdminpanelComponent){   
    
    this.getEncuestas();

    //Object.assign(this, { satisfaccionstorage });
  }

  ngOnInit() {
    this.getIncidences();
    this.getGraficoParticipacion();
    this.cargarDatosPorcCursoRealizado();
    this.getCoursesUsers();
  }
 
  getIncidences(): any {
    return this.adminpanelComponent.cargarIncidenciasPorUsuarios().subscribe(
      (data: any) => {
        //this.incidencias = data;

        // Aplicar la función de conversión de caracteres especiales como los acentuados...
        this.incidencias = data.map((item: { 
          cdescripcion: string; uninombre:string; unidescripcion: string; anombre:string; adescripcion: string; 
          pregunta: string; opcion1: string; opcion2: string; opcion3: string; opcion4: string;
        }) => {
          item.cdescripcion = this.adminpanelComponent.aplicarConversion(item.cdescripcion);
          item.uninombre = this.adminpanelComponent.aplicarConversion(item.uninombre);
          item.unidescripcion = this.adminpanelComponent.aplicarConversion(item.unidescripcion);
          item.anombre = this.adminpanelComponent.aplicarConversion(item.anombre);
          item.adescripcion = this.adminpanelComponent.aplicarConversion(item.adescripcion);
          item.opcion1 = this.adminpanelComponent.aplicarConversion(item.opcion1);
          item.opcion2 = this.adminpanelComponent.aplicarConversion(item.opcion2);
          item.opcion3 = this.adminpanelComponent.aplicarConversion(item.opcion3);
          item.opcion4 = this.adminpanelComponent.aplicarConversion(item.opcion4);
          return item;
        }); 

      },
      (error: string) => {
        console.log("getIncidences: no se pudieron recuperar datos. " + error);
      }
    );
  }

  getGraficoParticipacion(): any {
    return this.adminpanelComponent.cargarDatosGraficoParticipacion().subscribe(
      (data: any) => {
        this.participaccionstorage = data;     
      },
      (error: string) => {
        console.log("getGraficoParticipacion: no se pudieron recuperar datos. " + error);
      }
    );
  }  

  getEncuestas(): any {
    return this.adminpanelComponent.cargarDatosEncuestas().subscribe(
      (data: any) => {
        for (let indice in data){                 
          if(data[indice]['tipo']==1){ //encuesta com"plejidad
            this.encuesta1 = [{"name": "Alta", "value": data[indice]['puntaje_alto']},{"name": "Media", "value": data[indice]['puntaje_medio']},{"name": "Baja", "value": data[indice]['puntaje_bajo']}];
          }else{
            let elemento = {"name": "Opiniones", "series": [{"name": "Alto", "value": data[indice]['puntaje_alto']},{"name": "Media", "value": data[indice]['puntaje_medio']},{"name": "Baja", "value": data[indice]['puntaje_bajo']}]};                     
            if(data[indice]['tipo']==2){ //encuesta organizacion              
              this.encuesta2 = [elemento];
            }
            if(data[indice]['tipo']==3){ //encuesta metodologia enseñanza              
              this.encuesta3 = [elemento];
            }
            if(data[indice]['tipo']==4){ //encuesta desarrollo actividades
              this.encuesta4 = [elemento];
            }
            if(data[indice]['tipo']==5){ //encuesta percepción aprendizaje
              this.encuesta5 = [elemento];
            } 
          }
        } 

      },
      (error: string) => {
        console.log("getEncuesta: no se pudieron recuperar datos. " + error);
      }
    );
  }  

  cargarDatosPorcCursoRealizado(): any {
    return this.adminpanelComponent.cargarDatosPorcCursoRealizado().subscribe(
      (data: any) => {
        this.cursosterminadosstorage = data;     
      },
      (error: string) => {
        console.log("cargarDatosPorcCursoRealizado: no se pudieron recuperar datos. " + error);
      }
    );
  }  
  
  getCoursesUsers(): any {
    return this.adminpanelComponent.obtenerCursosUsuarios().subscribe(
      (data: any) => {
        this.cursos = data;     
      },
      (error: string) => {
        console.log("getCoursesUsers: no se pudieron recuperar datos. " + error);
      }
    );    
  }

  onTableDataChange(event: number) {
    this.page = event;
  }

  myFunctionSearch(event: any): void {
    //console.log("PASO: " + event.target.value);
    var input, filter, table, tr, td, i, txtValue;
    filter = this.myInput.nativeElement.value.toUpperCase();
    tr = this.myTable.nativeElement.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[0];
      if (td) {   
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

  detectarCambio(event: any, id: number) {

  } 

   
}

// Nota fuente de graficos: https://swimlane.gitbook.io/ngx-charts/installing

        // for (let clave in data){
        //   // Nuevo elemento que quieres agregar
        //   let nuevo = {
        //     "name": data['Curso'],
        //     "value": data['Cantidad_Estudiantes']
        //   };
        //   // Agregar el nuevo elemento al array
        //   participaccionstorage.push(nuevo);
        //   //console.log(data[clave]);
        // } 