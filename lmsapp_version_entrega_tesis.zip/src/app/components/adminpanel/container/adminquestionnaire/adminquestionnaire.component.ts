import { Component, ElementRef, ViewChild } from '@angular/core';
import {AdminpanelComponent} from '../../adminpanel.component';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-adminquestionnaire',
  templateUrl: './adminquestionnaire.component.html',
  styleUrls: ['./adminquestionnaire.component.css']
})
export class AdminquestionnaireComponent {

  public myform!: FormGroup;
  public cursos: any = [];
  public unidades: any = [];
  public actividades: any = [];
  public cuestionarios: any = [];
  public selected_courses: string | undefined;
  public selected_unit: string | undefined;
  public selected_activity: string | undefined;
  public selectedCourseInfoControl: FormControl<any>;
  public selectedUnitInfoControl: FormControl<any>;
  public selectedActivityInfoControl: FormControl<any>;
  
  public page = 1;
  public tableSize = 5;
  public count = 0;  
  
  @ViewChild('myTable')
  myTable!: ElementRef;

  @ViewChild('myInput')
  myInput!: ElementRef;
  
  constructor(private adminpanelComponent: AdminpanelComponent, private formBuilder: FormBuilder){
    this.selectedCourseInfoControl = new FormControl();
    this.selectedUnitInfoControl = new FormControl();
    this.selectedActivityInfoControl = new FormControl();
  }
  
  ngOnInit() {
       
    this.myform = this.formBuilder.group({
      textFormControlQuestion: ['', [Validators.required, Validators.minLength(2)]],
      textFormControlAnswerOption1: ['', [Validators.required, Validators.minLength(8)]],
      textFormControlAnswerOption2: [''],
      textFormControlAnswerOption3: [''],
      textFormControlAnswerOption4: [''],
      textFormControlAnswerCorrect: ['', [Validators.required]]
    });

    this.selectedCourseInfoControl.valueChanges.subscribe(value => {
      this.selected_courses = value;
    }); 

    this.selectedUnitInfoControl.valueChanges.subscribe(value => {
      this.selected_unit = value;
    });   

    this.selectedActivityInfoControl.valueChanges.subscribe(value => {
      this.selected_activity = value;
      this.getQuestionary(this.selected_unit!,this.selected_activity!);      
    });     

  }    


  onChangeSelectCourses(){

    this.getUnits(this.selected_courses!);

  }  

  onChangeSelectUnit(){

    this.getActivities(this.selected_unit!);

  }   


  onChangeSelectActivity(){
    

  }   


  getCourses(): any {

    return this.cursos = this.adminpanelComponent.obtenerCursos();

  }

  getUnits(idcurso:string): any {
    return this.adminpanelComponent.cargarTodosLasUnidadesPorCurso(idcurso).subscribe(
      (data: any) => {
        this.unidades = data;
      },
      (error: string) => {
        console.log("getUnits: no se pudieron recuperar datos. " + error);
      }
    );
  }    

  getActivities(idunidad:string): any {
    return this.adminpanelComponent.cargarTodosLasActividadesPorUnidad(idunidad).subscribe(
      (data: any) => {
        this.actividades = data;
      },
      (error: string) => {
        console.log("getActivities: no se pudieron recuperar datos. " + error);
      }
    );
  }  

  getQuestionary(idunidad:string, idactividad:string): any {
    return this.adminpanelComponent.cargarCuestionarioPorActividad(idunidad,idactividad).subscribe(
      (data: any) => {
        this.cuestionarios = data;
        //Aplicar la función de conversión de caracteres especiales como los acentuados...
        this.cuestionarios = data.map((item: {
          pregunta: string; opcion1: string; opcion2: string; opcion3: string; opcion4: string; 
}) => {
          item.pregunta = this.adminpanelComponent.aplicarConversion(item.pregunta);
          item.opcion1 = this.adminpanelComponent.aplicarConversion(item.opcion1);
          item.opcion2 = this.adminpanelComponent.aplicarConversion(item.opcion2);
          item.opcion3 = this.adminpanelComponent.aplicarConversion(item.opcion3);
          item.opcion4 = this.adminpanelComponent.aplicarConversion(item.opcion4);
          return item;
        }); 
      },
      (error: string) => {
        console.log("getQuestionary: no se pudieron recuperar datos. " + error);
      }
    );
  }  

  saveQuestion(){
    var pregunta   = this.myform.get("textFormControlQuestion")?.value;
    var opcion1 = this.myform.get("textFormControlAnswerOption1")?.value;
    var opcion2 = this.myform.get("textFormControlAnswerOption2")?.value;
    var opcion3 = this.myform.get("textFormControlAnswerOption3")?.value;
    var opcion4 = this.myform.get("textFormControlAnswerOption4")?.value;
    var respuesta = this.myform.get("textFormControlAnswerCorrect")?.value;
    var fkunidad = this.selected_unit;
    var fkactividad = this.selected_activity;
    var question = { "pregunta": pregunta, "opcion1": opcion1, "opcion2": opcion2, "opcion3": opcion3, "opcion4": opcion4, 
                      "respuesta": respuesta, "fkunidad": fkunidad, "fkactividad": fkactividad };

    opcion1 = (opcion1 === "")?"-":opcion1;
    opcion2 = (opcion2 === "")?"-":opcion2;
    opcion3 = (opcion3 === "")?"-":opcion3;
    opcion4 = (opcion4 === "")?"-":opcion4;

    this.adminpanelComponent.guardarCuestionario(question).subscribe(
      data => {
        var elemento = document.getElementById('mensajePreguntaGuardada');
        if (data['data'].estado == "OK") {
          elemento!.innerHTML = '<div class="alert alert-success" role="alert"><p>Se creo un nuevo cuestionario!!!</p></div>';
        } else {
          elemento!.innerHTML = '<div class="alert alert-danger" role="alert"><p>No fue posible crear el cuestionario!</p></div>';
        }
        setTimeout(() => {
          elemento!.innerHTML = "";
          this.myform.reset();
          this.getQuestionary(this.selected_unit!,this.selected_activity!);
        }, 3000);
      },
      error => {
        console.log("saveQuestion: no se pudieron recuperar datos. " + error);
      }
    );    
  }

// REVISAR....
  onTableDataChange(event: number) {
    this.page = event;
  }

  myFunctionSearch(event: any): void {
    // console.log("PASO: " + event.target.value);
    var input, filter, table, tr, td, i, txtValue;
    filter = this.myInput.nativeElement.value.toUpperCase();
    tr = this.myTable.nativeElement.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[0];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

  detectarCambio(event: any, id: number) {
    // Verifica si la tecla presionada es "Enter"
    if (event.keyCode === 13) {
      var el1 = document.getElementById("inputPregunta-" + id);
      var contenido1 = el1!.textContent;
      var el2 = document.getElementById("inputPregunta-" + id);
      var contenido2 = el2!.textContent;
      var el3 = document.getElementById("inputOpcion2-" + id);
      var contenido3 = el3!.textContent;
      var el4 = document.getElementById("inputOpcion3-" + id);
      var contenido4 = el4!.textContent;
      var el5 = document.getElementById("inputOpcion4-" + id);
      var contenido5 = el5!.textContent;
      var el6 = document.getElementById("inputRespuesta-" + id);
      var contenido6 = el6!.textContent;
      var el7 = document.getElementById("inputUnidad-" + id);
      var contenido7 = el7!.textContent;      
      var el8 = document.getElementById("inputActividad-" + id);
      var contenido8 = el8!.textContent;      

      console.log('Se presionó Enter en detectarCambio');
      var cuestionario = { "id": id, "pregunta": contenido1, "opcion1": contenido2, "opcion2": contenido3, "opcion3": contenido4, "opcion4": contenido5,
                          "respuesta": contenido6, "fkunidad": contenido7, "fkactividad": contenido8 };
      this.adminpanelComponent.modificarCuestionario(cuestionario).subscribe(
        data => {
          if (data['data'].estado == "OK") {
            this.getCourses();
          }
        },
        error => {
          console.log("detectarCambio: no se pudieron recuperar datos. " + error);
        }
      );
    }
  }


}
