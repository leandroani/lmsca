import { Component, ElementRef, ViewChild } from '@angular/core';
import {AdminpanelComponent} from '../../adminpanel.component';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
declare var $: any;


@Component({
  selector: 'app-adminunits',
  templateUrl: './adminunits.component.html',
  styleUrls: ['./adminunits.component.css']
})
export class AdminunitsComponent {
  
  public myform!: FormGroup;
  public cursos: any = [];
  public unidades: any = [];
  public selected_courses: string | undefined;
  public selectedCourseInfoControl: FormControl<any>;
  
  public page = 1;
  public tableSize = 5;
  public count = 0;

  @ViewChild('myTable')
  myTable!: ElementRef;

  @ViewChild('myInput')
  myInput!: ElementRef;
    
  constructor(private adminpanelComponent: AdminpanelComponent, private formBuilder: FormBuilder){
    this.selectedCourseInfoControl = new FormControl();
  }

  ngOnInit() {
   
    this.myform = this.formBuilder.group({
      titleFormControlInput2: ['', [Validators.required, Validators.minLength(2)]],
      descripFormControlInput2: ['', [Validators.required, Validators.minLength(2)]]
    });

    this.selectedCourseInfoControl.valueChanges.subscribe(value => {
      this.selected_courses = value;
      this.getUnits(this.selected_courses!);
    }); 

  }      

  getCourses(): any {
    
    return this.cursos = this.adminpanelComponent.obtenerCursos();
    
  }

  getUnits(idcurso:string): any {
    return this.adminpanelComponent.cargarTodosLasUnidadesPorCurso(idcurso).subscribe(
      (data: any) => {
        this.unidades = data;
      },
      (error: string) => {
        console.log("getUnits: no se pudieron recuperar datos. " + error);
      }
    );
  }  

  saveUnit(){
    var elemento = document.getElementById('mensajeUnidad');    
    if(typeof this.selected_courses === 'undefined'){
      elemento!.innerHTML = '<div class="alert alert-danger" role="alert"><p>Debes seleccionar un Curso!!!</p></div>';    
      setTimeout(() => {
        elemento!.innerHTML = "";
      }, 3000);
    }else{   
      var titulo = this.myform.get("titleFormControlInput2")?.value;
      var descripcion = this.myform.get("descripFormControlInput2")?.value;        
      var unidad = { "name": titulo, "description": descripcion, "course": this.selected_courses};
      this.adminpanelComponent.guardarUnidad(unidad).subscribe(
        data => {
              if (data['data'].estado == "OK") {
            elemento!.innerHTML = '<div class="alert alert-success" role="alert"><p>Se creo un nuevo unidad!!!</p></div>';    
              } else {
            elemento!.innerHTML = '<div class="alert alert-danger" role="alert"><p>No fue posible crear un unidad!</p></div>';
          }
          setTimeout(() => {
            elemento!.innerHTML = "";
            this.myform.reset();
            this.getUnits(this.selected_courses!);
          }, 3000);
        },
        error=> {
          console.log("saveUnit: no se pudieron recuperar datos. " + error);
        }
      );    
    }
  }

  myFunctionSearch(event: any): void {
    var input, filter, table, tr, td, i, txtValue;
    filter = this.myInput.nativeElement.value.toUpperCase();
    tr = this.myTable.nativeElement.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[0];
      if (td) {
        txtValue = td.textContent || td.innerText;        
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

  detectarCambio(event: any,id:number) {
    // Verifica si la tecla presionada es "Enter"
    if (event.keyCode === 13) {
      var el1 = document.getElementById("inputName-"+id);
      var contenido1 = el1!.textContent;
      var el2 = document.getElementById("inputDescription-"+id);
      var contenido2 = el2!.textContent;
      var el3 = document.getElementById("inputOrden-"+id);
      var contenido3 = el3!.textContent;        
      var el4 = document.getElementById("inputEstado-"+id);
      var contenido4 = el4!.textContent;            
      var el5 = document.getElementById("inputCurso-"+id);
      var contenido5 = el5!.textContent;                  
      var unidad = { "idunidad":id, "nombre": contenido1, "descripcion": contenido2, "orden": contenido3, "estado":contenido4, "fkcurso":contenido5 };
      this.adminpanelComponent.modificarUnidad(unidad).subscribe(
        data => {
          if (data['data'].estado == "OK") {
            this.getUnits(this.selected_courses!);
          }
        },
        error => {
          console.log("detectarCambio: no se pudieron recuperar datos. " + error);
        }
      );
    }
  }

  onTableDataChange(event: number) {
    this.page = event;
  }

}
