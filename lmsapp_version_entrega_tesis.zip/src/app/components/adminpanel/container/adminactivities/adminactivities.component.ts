import { Component, ElementRef, ViewChild } from '@angular/core';
import { AdminpanelComponent } from '../../adminpanel.component';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
declare var $: any;

@Component({
  selector: 'app-adminactivities',
  templateUrl: './adminactivities.component.html',
  styleUrls: ['./adminactivities.component.css']
})
export class AdminactivitiesComponent {

  public myform!: FormGroup;
  public cursos: any = [];
  public unidades: any = [];
  public actividades: any = [];
  public selected_courses: string | undefined;
  public selected_unit: string | undefined;
  public selectedCourseInfoControl: FormControl<any>;
  public selectedUnitInfoControl: FormControl<any>;
  public fileList: File[] = [];
  public msgLoadFiles: string = "";

  public page = 1;
  public tableSize = 5;
  public count = 0;

  @ViewChild('myTable')
  myTable!: ElementRef;

  @ViewChild('myInput')
  myInput!: ElementRef;

  constructor(private adminpanelComponent: AdminpanelComponent, private formBuilder: FormBuilder) {
    this.selectedCourseInfoControl = new FormControl();
    this.selectedUnitInfoControl = new FormControl();
  }

  ngOnInit() {

    //this.getCourses();

    this.myform = this.formBuilder.group({
      titleFormControlInput: ['', [Validators.required, Validators.minLength(2)]],
      descriptionFormControlTextarea: ['', [Validators.required, Validators.minLength(2)]],
      imagen: ['', [Validators.required]]
    });

    this.selectedCourseInfoControl.valueChanges.subscribe(value => {
      this.selected_courses = value;
    });

    this.selectedUnitInfoControl.valueChanges.subscribe(value => {
      this.selected_unit = value;
    });

  }

  onChangeSelectCourses() {

    this.getUnits(this.selected_courses!);

  }

  onChangeSelectUnit() {

    this.getActivities(this.selected_unit!);

  }

  getCourses(): any {
    
    return this.cursos = this.adminpanelComponent.obtenerCursos();

  }

  getUnits(idcurso: string): any {
    return this.adminpanelComponent.cargarTodosLasUnidadesPorCurso(idcurso).subscribe(
      (data: any) => {
        this.unidades = data;
      },
      (error: string) => {
        console.log("getUnits: no se pudieron recuperar datos. " + error);
      }
    );
  }

  getActivities(idunidad: string): any {
    return this.adminpanelComponent.cargarTodosLasActividadesPorUnidad(idunidad).subscribe(
      (data: any) => {
        this.actividades = data;
      },
      (error: string) => {
        console.log("getActivities: no se pudieron recuperar datos. " + error);
      }
    );
  }

  onFileSelected(event: any) {
    this.fileList = [];
    for (var i = 0; i <= event.target.files.length - 1; i++) {
      var selectedFile = event.target.files[i];
      console.log("Nombre del archivo: " + selectedFile.name);
      this.fileList.push(selectedFile);
    }
    this.adminpanelComponent.uploadFile(this.fileList).subscribe(response => {
      if (response.estado == "ok") {
        this.msgLoadFiles = "Archivo seleccionado con exito!";
        this.myform.controls['imagen'].setValue(response.urls);
        // muestro la imagen seleccionada
        var imagen = '../assets/upload/' + response.urls;
        console.log("Nuevo nombre del archivo imagen cargado...: " + imagen);
        var elemento = document.createElement("img");
        elemento.setAttribute("src", imagen);
        elemento.setAttribute("width", "400px");
        elemento.setAttribute("height", "255px");
        var actual = document.getElementById('imagen_actividad');
        actual!.appendChild(elemento);
      } else {
        this.msgLoadFiles = "Algo salio mal!";
      }
    });
  }

  saveActivity() {

    var nombre = this.myform.get("titleFormControlInput")?.value;
    var descripcion = this.myform.get("descriptionFormControlTextarea")?.value;
    var estado = 1;
    var imagen = this.myform.get("imagen")?.value;
    var recurso = '../assets/upload/' + imagen;
    var fkunidad = this.selected_unit;
    var actividad = { "nombre": nombre, "descripcion": descripcion, "estado": estado, "recurso": recurso, "fkunidad": fkunidad };

    this.adminpanelComponent.guardarActividad(actividad).subscribe(
      data => {
        var elemento = document.getElementById('mensajeActividadGuardada');
        if (data['data'].estado == "OK") {
          elemento!.innerHTML = '<div class="alert alert-success" role="alert"><p>Se creo una nueva actividad!!!</p></div>';
        } else {
          elemento!.innerHTML = '<div class="alert alert-danger" role="alert"><p>No fue posible crear una actividad!</p></div>';
        }
        setTimeout(() => {
          elemento!.innerHTML = "";
          this.myform.reset();
          this.getActivities(this.selected_unit!);
        }, 3000);
      },
      error => {
        console.log("saveActivity: no se pudieron recuperar datos. " + error);
      }
    );

  }

  onTableDataChange(event: number) {
    this.page = event;
  }

  myFunctionSearch(event: any): void {
    // console.log("PASO: " + event.target.value);
    var input, filter, table, tr, td, i, txtValue;
    filter = this.myInput.nativeElement.value.toUpperCase();
    tr = this.myTable.nativeElement.getElementsByTagName("tr");
    for (i = 0; i < tr.length; i++) {
      td = tr[i].getElementsByTagName("td")[0];
      if (td) {
        txtValue = td.textContent || td.innerText;
        if (txtValue.toUpperCase().indexOf(filter) > -1) {
          tr[i].style.display = "";
        } else {
          tr[i].style.display = "none";
        }
      }
    }
  }

  detectarCambio(event: any, id: number) {
    // Verifica si la tecla presionada es "Enter"
    if (event.keyCode === 13) {
      var el1 = document.getElementById("inputName-" + id);
      var contenido1 = el1!.textContent;
      var el2 = document.getElementById("inputDescription-" + id);
      var contenido2 = el2!.textContent;
      var el3 = document.getElementById("inputEstado-" + id);
      var contenido3 = el3!.textContent;
      var el4 = document.getElementById("inputImagen-" + id);
      var contenido4 = el4!.textContent;
      var el5 = document.getElementById("inputUnidad-" + id);
      var contenido5 = el5!.textContent;
      console.log('Se presionó Enter en detectarCambio');
      var actividad = { "idactividad": id, "nombre": contenido1, "descripcion": contenido2, "estado": contenido3, "recurso": contenido4, "fkunidad": contenido5 };
      this.adminpanelComponent.modificarActividad(actividad).subscribe(
        data => {
          if (data['data'].estado == "OK") {
            this.getCourses();
          }
        },
        error => {
          console.log("detectarCambio: no se pudieron recuperar datos. " + error);
        }
      );
    }
  }

}
