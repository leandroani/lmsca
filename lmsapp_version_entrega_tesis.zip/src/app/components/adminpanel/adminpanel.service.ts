import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'environments';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AdminpanelService {

  constructor(private http: HttpClient) { }

  getUsersAll(): Observable<any> {
    return this.http.get(environment.URL + "/usersall");
  }  

  saveUser(user: any): Observable<any>{
    return this.http.post(environment.URL + "/user", JSON.stringify(user));    
  }

  getCoursesAll(): Observable<any> {
    return this.http.get(environment.URL + "/courses");
  }  
  
  getCoursesById(iduser: any): Observable<any> {
    return this.http.get(environment.URL + "/coursesbyuser"+iduser );
  }

  getCoursesUsers(): Observable<any> {
    return this.http.get(environment.URL + "/coursesmergeuser");
  }  

  saveCourse(course: any): Observable<any>{
    return this.http.post(environment.URL + "/courses", JSON.stringify(course));    
  }

  updateCourse(course: any): Observable<any>{
    return this.http.put(environment.URL + "/courses", JSON.stringify(course));    
  }  

  saveUserByCourse(param: any): Observable<any>{
    return this.http.post(environment.URL + "/userbycourse", JSON.stringify(param));    
  }

  getUnitsByCourses(idcourse: any): Observable<any> {
    return this.http.get(environment.URL + "/unitsbycourse/"+idcourse);
  }  
 
  saveUnit(param: any): Observable<any>{
    return this.http.post(environment.URL + "/unit", JSON.stringify(param));    
  }

  updateUnit(unit: any): Observable<any>{
    return this.http.put(environment.URL + "/unit", JSON.stringify(unit));    
  }  
  
  getActivitiesByUnit(idunit: any): Observable<any> {
    return this.http.get(environment.URL + "/activities/"+idunit);
  } 

  saveActivity(param: any): Observable<any>{   
    return this.http.post(environment.URL + "/activity", JSON.stringify(param));    
  }

  updateActivity(activity: any): Observable<any>{
    const headers = new HttpHeaders({
      'Content-Type': 'application/json; charset=ISO-8859-1'
    });    
    return this.http.put(environment.URL + "/activity", JSON.stringify(activity),{ headers: headers });    
  } 

  getQuestionaryByActivity(idunit: any, idactivity: any): Observable<any> {
    return this.http.get(environment.URL + "/questionsbyactivity/"+idunit+"/"+idactivity);
  } 

  saveQuestionary(param: any): Observable<any>{
    return this.http.post(environment.URL + "/questionary", JSON.stringify(param));    
  }

  updateQuestionary(questionary: any): Observable<any>{
    return this.http.put(environment.URL + "/questionary", JSON.stringify(questionary));    
  }   

  uploadFile(myFiles: any): Observable<any> {
    const formData = new FormData();
    for (var i = 0; i < myFiles.length; i++) {
      formData.append("file[]", myFiles[i]); //console.log("Archivo: " + myFiles[i].name);
    }
    var uploadfile = environment.URL.replace('index.php','upload.php');
    return this.http.post(uploadfile, formData);
  }  

  getIncidences(): Observable<any> {
    return this.http.get(environment.URL + "/incidences");
  }  

  getDataGraphParticipation(): Observable<any> {
    return this.http.get(environment.URL + "/graficoparticipacion");
  } 
  
  getDataQuizzes(): Observable<any> {
    return this.http.get(environment.URL + "/quizzes");
  } 

  getDataPorcCourseCompleted(): Observable<any> {
    return this.http.get(environment.URL + "/coursecompleted");
  } 


}

    // let queryParams = new HttpParams();
    // queryParams = queryParams.append("course",idcourse);    
    //return this.http.get(environment.URL + "/unitsbycourse",{params:queryParams});